.. The Cement CLI Application Framework documentation master file, created by
   sphinx-quickstart on Thu Jan 28 02:44:35 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Cement CLI Application Framework Documentation!
================================================================

Cement is an advanced CLI Application Framework for Python. This documentation
is a guide for developers wishing to build their applications on top of the 
Cement Framework.  Other sites that might be helpful:

 * http://pypi.python.org/pypi/Cement
 * http://github.com/derks/cement
 * http://wiki.builtoncement.org
 
Contents:

.. toctree::
   :maxdepth: 2

   api
   dev

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
