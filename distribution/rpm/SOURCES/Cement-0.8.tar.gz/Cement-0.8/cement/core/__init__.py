"""Cement core module, holds all core framework code."""
__import__('pkg_resources').declare_namespace(__name__)
