"""sayhi model classes."""

class sayhiModel(object):
    # define model class
    pass